
package swcom;

import java.io.*;
import java.util.HashMap;


public class Diccionario {
    private String URL;	
    private String juego_caracteres;
    private HashMap<String, Integer> Palabras = new HashMap<String, Integer>(); //Lista de palabras 
	
	public Diccionario(String u, String jc) {
	    this.URL=u;
            this.juego_caracteres=jc;
             try{
		FileInputStream fis = new FileInputStream(this.URL);
		InputStreamReader is = new InputStreamReader(fis,this.juego_caracteres);
		BufferedReader bf = new BufferedReader(is);
		String linea;
		int i=1;
		while ((linea = bf.readLine()) != null) {
                    this.Palabras.put(linea.toLowerCase(),i++);
		}
		bf.close();
		is.close();
		fis.close();
				
	}catch(Exception e){
			
        }
        }
	public Boolean Buscar(String s) {
		if(this.Palabras.containsKey(s)) return true;
		return false;
	
	}
}