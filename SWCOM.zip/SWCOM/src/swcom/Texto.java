
package swcom;

import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Texto {
    private String URL;	
    private String juego_caracteres;
    private ArrayList<Palabra> Palabras = new ArrayList<Palabra>(); //Lista de palabras 
	
	public Texto(String u, String jc) {
	    this.URL=u;
            this.juego_caracteres=jc;
             try{
		FileInputStream fis = new FileInputStream(this.URL);
		InputStreamReader is = new InputStreamReader(fis,this.juego_caracteres);
		BufferedReader bf = new BufferedReader(is);
		String linea;
		int nlinea=1;
                 String delimitadores= "[ .,:;?!¡¿()0123456789\'\"\\[\\]]+";
		while ((linea = bf.readLine()) != null){                          
                    String[] palabrasSeparadas = linea.split(delimitadores);
                    for (int i=0;i<palabrasSeparadas.length;i++){ 
                        Palabra p = new Palabra();
                        p.SetValor(palabrasSeparadas[i].toLowerCase());
                        p.SetLinea(nlinea);
                        this.Palabras.add(p);
                    }
                    nlinea++;
		}
		bf.close();
		is.close();
		fis.close();
				
	}catch(Exception e){
			
        }
        }
	public int CountPalabras(){
            return Palabras.size();
        }
        public Palabra GetPalabra(int i){
           return Palabras.get(i);
	
	}
}
