package swcom;
import java.util.ArrayList;

public class SWCOM {
    public static void main(String[] args) {
       ArrayList<String> correccion = new ArrayList<String> ();
        Texto t = new Texto(args[0],args[2]);
	Diccionario d = new Diccionario(args[1],args[2]);
        System.out.println("<?xml version=\"1.0\" econding=\"ISO-8859-1\"?");
        System.out.println("<texto>"+args[0]+"</texto>");
        System.out.println("<diccionario>"+args[1]+"</diccionario>");
        Corrector c = new Corrector(d);
        for (int i=0;i<t.CountPalabras();++i){
            if (!d.Buscar(t.GetPalabra(i).getValor())){
                    System.out.println("<error>");
                    System.out.println("<palabra>"+ t.GetPalabra(i).getValor() + "</palabra>");
                    System.out.println("<linea>"+ t.GetPalabra(i).getLinea() + "</linea>");
                    System.out.println("<sugerencias>");
                    correccion=c.Ortografia(t.GetPalabra(i).getValor());
                    for (int j=0;j<correccion.size();++j) System.out.println("<sugerencia>"+correccion.get(j)+"</sugerencia>");
                    System.out.println("</sugerencias>");
                    System.out.println("</error>");
            }        
            
        }
    }
}




